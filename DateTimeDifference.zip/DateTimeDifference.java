package com.newJava;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class DateTimeDifference {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter date and time in DD-MM-YYYY hh:mm format: ");
        String input = scanner.nextLine();
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        Date currentDate = new Date();
        
        try {
            Date enteredDate = dateFormat.parse(input);
            long diffInMilliseconds = enteredDate.getTime() - currentDate.getTime();
            
            if (diffInMilliseconds < 0) {
                System.out.println("Invalid date.");
            } else {
                long years = TimeUnit.MILLISECONDS.toDays(diffInMilliseconds) / 365;
                long months = TimeUnit.MILLISECONDS.toDays(diffInMilliseconds) / 30;
                long weeks = TimeUnit.MILLISECONDS.toDays(diffInMilliseconds) / 7;
                long days = TimeUnit.MILLISECONDS.toDays(diffInMilliseconds);
                long minutes = TimeUnit.MILLISECONDS.toMinutes(diffInMilliseconds);
                
                if (years > 0) {
                    System.out.println("Difference in years: " + years);
                } else if (months > 0) {
                    System.out.println("Difference in months: " + months);
                } else if (weeks > 0) {
                    System.out.println("Difference in weeks: " + weeks);
                } else if (days > 0) {
                    System.out.println("Difference in days: " + days);
                } else if (minutes > 0) {
                    System.out.println("Difference in minutes: " + minutes);
                } else {
                    System.out.println("The entered date is today and time is in future.");
                }
            }
        } catch (Exception e) {
            System.out.println("Invalid date.");
        }
        
        scanner.close();

    }
}


