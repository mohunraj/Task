package com.newJava;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;


public class Thirdtask {

	public static void main(String[] args) {
		HashSet<String> emailsFile1 = readEmailsFromFile("file1.txt");
        HashSet<String> emailsFile2 = readEmailsFromFile("file2.txt");

        // Print emails that are present in both files
        System.out.println("Emails present in both files:");
        for (String email : emailsFile1) {
            if (emailsFile2.contains(email)) {
                System.out.println(email);
            }
        }

        // Print emails that are present in file1 but not in file2
        System.out.println("\nEmails present in file1 but not in file2:");
        for (String email : emailsFile1) {
            if (!emailsFile2.contains(email)) {
                System.out.println(email);
            }
        }

        // Print emails that are present in file2 but not in file1
        System.out.println("\nEmails present in file2 but not in file1:");
        for (String email : emailsFile2) {
            if (!emailsFile1.contains(email)) {
                System.out.println(email);
            }
        }

        // Print all unique emails present in both files
        System.out.println("\nUnique emails present in both files:");
        HashSet<String> uniqueEmails = new HashSet<>(emailsFile1);
        uniqueEmails.addAll(emailsFile2);
        for (String email : uniqueEmails) {
            System.out.println(email);
        }
    }

    private static HashSet<String> readEmailsFromFile(String fileName) {
        HashSet<String> emails = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                emails.add(line.trim());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return emails;
    }
}

	